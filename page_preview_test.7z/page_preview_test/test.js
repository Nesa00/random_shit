document.addEventListener('DOMContentLoaded', function() {
    const preview = document.getElementById('preview');
    const previewFrame = document.getElementById('previewFrame');

    document.querySelectorAll('.preview').forEach(function(link) {
        link.addEventListener('mouseover', function() {
            const href = this.getAttribute('href');
            previewFrame.src = href;
            preview.style.display = 'block';
            preview.style.top = (this.getBoundingClientRect().top + window.scrollY + 20) + 'px';
            preview.style.left = (this.getBoundingClientRect().left + window.scrollX) + 'px';
        });

        link.addEventListener('mouseout', function() {
            preview.style.display = 'none';
            previewFrame.src = '';
        });
    });
});
